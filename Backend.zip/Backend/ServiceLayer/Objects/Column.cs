﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroSE.Kanban.Backend.ServiceLayer.Objects
{
    class Column
    {
        public readonly string name;
        private List<Task> tasks;
        private int numberOfTasks;
      
        internal Column(string name)
        {
            this.name = name;
            this.numberOfTasks = 0;
            
            tasks = new List<Task>();
        }

    }
}
