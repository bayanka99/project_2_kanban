﻿using IntroSE.Kanban.Backend.DataAccessLayer.DTOs;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace IntroSE.Kanban.Backend.BusinessLayer
{
    enum ColumnName
    {
        Backlog = 0,
        InProgress,
        Done
    }
    internal class Board
    {
        private int id { get; set; }
        public int getId { get => id; }
        private string adminUser { get; set; }
        public string getAdminUser { get => adminUser; }
        private string name { get; set; }
        public string getName { get => name; }

        private Dictionary<string, Column> columns;
        private List<string> members;

        public string getMembersInString()  {
            string ret = "";
            foreach (string s in members)
            {
                ret += s+",";
            }
            return ret.Substring(0, ret.Length-1);
        }
        //Constructor
        internal Board(string name, string adminUser)
        {
            
            this.adminUser = adminUser;
            this.id = IDRandom(new Random());
            this.columns = new Dictionary<string, Column>();
            this.name = name;
            this.members = new List<string>();
            this.members.Add(adminUser);
            columns.Add("backlog", new Column("backlog"));
            columns.Add("in progress", new Column("in progress"));
            columns.Add("done", new Column("done"));
            //this.Persist();//save to file
        }
        internal Board(BoardDTO boardDTO , List<TaskDTO> tasksDTO)
        {
            this.adminUser = boardDTO.email;
            this.id = int.Parse(boardDTO.Id.ToString());
            this.columns = new Dictionary<string, Column>();
            this.name = boardDTO.boardname;
            columns.Add("backlog", new Column("backlog"));
            columns.Add("in progress", new Column("in progress"));
            columns.Add("done", new Column("done"));
            foreach (TaskDTO task in tasksDTO)
            {
                columns[task.taskcurrentColumnName].addTask(new Task(task),true);
            }
            string[] membersS = boardDTO.members.Split(',');
            this.members = new List<string>();
            foreach (string member in membersS)
                members.Add(member);
            columns[getColName(0)].setLimit(int.Parse(boardDTO.collimit0));
            columns[getColName(1)].setLimit(int.Parse(boardDTO.collimit1));
            columns[getColName(2)].setLimit(int.Parse(boardDTO.collimit2));
            //this.Persist();//save to file
        }
        /*
        The function checks if the task exists in the column
        Input:
            1)Task task - The task being tested
            2)int colOrd - The current column of the task
        Output:None
        */
        private void isTaskExsitsInCol(Task task, int colOrd)
        {
            if(!getCol(colOrd).containTask(task))
            {
                throw new ArgumentException("The task is not in this column");
            }
        }

        /*
        The function advances the task
        Input:
            1)Task task - The task being advanced
            2)int colOrd - The current column of the task
        Output:None
        */
        public void moveTask(Task task, int colOrd)
        {
            
            isTaskExsitsInCol(task, colOrd);
            isDone(colOrd);
            columns[getColName(colOrd + 1)].addTask(task,false);
            columns[getColName(colOrd)].deleteTask(task);
        }

        /*
        The function update the task
        Input:
            1)Task task - The task being update
            2)Task newTask - The new task
            2)int colOrd - The current column of the task
        Output:None
        */
        public void updateTask(Task newTask, int colOrd)
        {
            isDone(colOrd);
            columns[getColName(colOrd)].deleteTask(getTask(colOrd,newTask.getID));
            columns[getColName(colOrd)].addTask(newTask, false);
        }

        /*
        The function add new task to board
        Input:Task task - The task being added
        Output:None
        */
        public void addTask(Task task)
        {
            columns["backlog"].addTask(task, false);
        }

        /*
        This function returns the requested column
        Input:int colOrd - ordinal of the requested column
        Output:Column - The requested column
        */
        internal Column getCol(int colOrd)
        {
            if(colOrd==0 | colOrd == 1 | colOrd ==2)
            {
                return columns[getColName(colOrd)];
            }
            else
            {
                throw new ArgumentException("column id must be between 0 and 2");
            }
            
        }

        /*
        This function returns the name of requested column
        Input:int colOrd - ordinal of the requested column
        Output:string - The requested column name
        */
        internal string getColName(int colOrd)
        {
            string ret;
            switch (colOrd)
            {
                case (int)ColumnName.Backlog:
                    ret = "backlog";
                    break;
                case (int)ColumnName.InProgress:
                    ret = "in progress";
                    break;
                case (int)ColumnName.Done:
                    ret = "done";
                    break;
                default:
                    throw new ArgumentException("Column ordinal must be a 0 (Backlog),1(InProgress) or 2(Done)");
            }
            return ret;
        }

        /*
        This function checks if the column is done
        Input:int colOrd - ordinal of the column
        Output:None
        */
        private void isDone(int colOrd)
        {
            if (colOrd == (int)ColumnName.Done)
            {
                throw new ArgumentException("The task done cannot move!");
            }
        }

        int IDRandom(Random rand)
        {
            int result = rand.Next((Int32)(100 >> 32), (Int32)(100000000 >> 32));
            result = (result << 32);
            result = result | (int)rand.Next((Int32)100, (Int32)100000000);
            return result;
        }

        /*
         checks if given string is the board creator
        */
        internal bool isCreator(string email)
        {
            return adminUser.Equals(email);
        }


        internal void JoinBoard(string userEmail)
        {
            if(members.Contains(userEmail))
            {
                throw new ArgumentException("User " + userEmail + " already a member of this board: " + name);
            }
            this.members.Add(userEmail);

        }

        internal bool isMemeber(string member)
        {
            return this.members.Contains(member);
        }

        internal Task getTask(int colOrd, int taskID)
        {
            return columns[getColName(colOrd)].getTask(taskID);
        }
        internal List<Task> getInProgress()
        {
            return columns["in progress"].getTasks;
        }



        //private void Persist()
        //{
        //    ToDalObject().Save();
        //}


    }
}
